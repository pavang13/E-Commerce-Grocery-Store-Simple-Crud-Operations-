import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Logindata } from './logindata';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpClient:HttpClient) { }

  baseurl="http://localhost:8090/userservice"

  onLogin(data:Logindata){
    return this.httpClient.post<any>(this.baseurl+"/login",data)
  }
  
}
