import { Component } from '@angular/core';
import { Signupdata } from './signupdata';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'E2Eapp';
  signupdata = Signupdata;
}
