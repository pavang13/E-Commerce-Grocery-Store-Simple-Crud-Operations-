export class Signupdata {
    constructor(public userid?:number,public emailId?: string, public username?: string, public password?: string, public address?: string) { }
}
