import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { GetitemComponent } from './getitem/getitem.component';
import { AdditemComponent } from './additem/additem.component';
import { UpdateComponent } from './update/update.component';
import { DeleteComponent } from './delete/delete.component';


const routes: Routes = [
  {
    path:"signup",
    component:SignupComponent
  },
  {
    path:"login",
    component:LoginComponent
  },
  {
    path:"getitem",
    component:GetitemComponent
  },
  {
    path:"additem",
    component:AdditemComponent
  },
  {
    path:"update",
    component:UpdateComponent
  },
  {
    path:"delete",
    component:DeleteComponent
  }
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
