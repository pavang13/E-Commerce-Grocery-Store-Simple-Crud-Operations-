import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ItemserviceService } from '../itemservice.service';
import { Router } from '@angular/router';
import { Itemsdata } from '../itemsdata';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  itemCode=new FormControl('');

  update(){
    console.log(this.itemCode.value);
    window.localStorage.setItem("c1",this.itemCode.value)
    //this.redirect.navigateByUrl('/updateitem');
    this.redirect.navigate(['/update']);
  }

  deleteItem(){
    console.log(this.itemCode.value);
    window.localStorage.setItem("c2",this.itemCode.value)
    this.itemservice.onDelete().subscribe(
      result=>{
        console.log(result)
        alert("item Deleted")
        this.redirect.navigateByUrl('/getitem');
      },
      error=>{
        console.log(error)
        alert("Item doesn't exist")
        this.redirect.navigateByUrl('/getitem');
      }
    )
  }

  constructor(private redirect:Router,private itemservice:ItemserviceService) { }

  ngOnInit(): void {
  }

}
