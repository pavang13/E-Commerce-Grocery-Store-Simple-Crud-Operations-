export class Logindata {
    constructor(public userid?: string, public password?: string) { }
}
