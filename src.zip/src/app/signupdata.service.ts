import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Signupdata } from './signupdata';

@Injectable({
  providedIn: 'root'
})
export class SignupdataService {

  constructor(private httpClient:HttpClient) { }

  baseurl:string="http://localhost:8060/product/user"

  registeruser(data:Signupdata){
    return this.httpClient.post<any>(this.baseurl+"/register",data);
  }
}
