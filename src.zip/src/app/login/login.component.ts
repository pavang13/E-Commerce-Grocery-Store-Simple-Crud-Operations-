import { Component, Input, OnInit } from '@angular/core';
import { FormControl,FormGroup,FormArray, Validators } from '@angular/forms';
import { Logindata } from '../logindata';
import { LoginService } from '../login.service';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  logindata!: Logindata;

  @Input() isLoggedIn:false;

  constructor(private LoginService: LoginService,private redirect:Router) { 
    window.localStorage.clear;
  }

  LoginForm=new FormGroup({
    userid:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required])

  })

  get userid(){
    return this.LoginForm.get('userid')
  }
  get password(){
    return this.LoginForm.get('password')
  }

  onLogin(){
    this.logindata=this.LoginForm.value;
    this.LoginService.onLogin(this.logindata).subscribe(
      success=>{
        console.log(success)
        window.localStorage.setItem("tkn",success.token)
        this.redirect.navigateByUrl('/getitem')
      },
      failure=>{
        console.log(failure)
        alert("login failed")
        this.redirect.navigateByUrl('');
      }
    )
  }


  
  


  ngOnInit(): void {
  }

}
