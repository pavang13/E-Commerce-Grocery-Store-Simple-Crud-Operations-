import { Component, OnInit } from '@angular/core';
import { Itemsdata } from '../itemsdata';
import { ItemserviceService } from '../itemservice.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-getitem',
  templateUrl: './getitem.component.html',
  styleUrls: ['./getitem.component.css']
})
export class GetitemComponent implements OnInit {
  today: Date = new Date() ;
  pipe=new DatePipe('en-US');
  todayWithPipe=this.pipe.transform(Date.now(),'yyyy-mm-dd');
  allitems:any;

  display(){
    this.itemservice.display().subscribe(
      result=>{
        console.log(this.todayWithPipe)
        this.allitems=result;
      }
    )

  }

  date(){
    return Date.toString;
  }

  constructor(private itemservice:ItemserviceService) { }

  ngOnInit(): void {
  }

}
