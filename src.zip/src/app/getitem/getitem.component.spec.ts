import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetitemComponent } from './getitem.component';

describe('GetitemComponent', () => {
  let component: GetitemComponent;
  let fixture: ComponentFixture<GetitemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetitemComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetitemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
