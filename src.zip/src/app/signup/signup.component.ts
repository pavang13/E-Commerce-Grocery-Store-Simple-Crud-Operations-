import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,FormArray, Validators } from '@angular/forms';
import { SignupdataService } from '../signupdata.service';
import { Signupdata } from '../signupdata';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  constructor(private signupdataService:SignupdataService) { }

  signupdata!: Signupdata;
signup= new FormGroup(
  {
    userid:new FormControl('',[Validators.required]),
    emailId:new FormControl('',[Validators.required]),
    username:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
    address:new FormControl('',[Validators.required]),
  }
)

get userid(){
  return this.signup.get('userid')
}
get emailId(){
  return this.signup.get('emailId')
};
get username(){
  return this.signup.get('emailId')
};
get password(){
  return this.signup.get('emailId')
};
get address(){
  return this.signup.get('emailId')
};

onSubmit(){
  console.warn(this.signup.value);
  this.signupdata={
    userid:parseInt(this.signup.get('userid').value),
    emailId:this.signup.get('emailId').value,
    username:this.signup.get('username').value,
    password:this.signup.get('password').value,
    address:this.signup.get('address').value

  };
  console.log(this.signupdata);
  this.signupdataService.registeruser(this.signupdata!).subscribe(
    result=>{
      console.log("Registration success "+result)
      alert("You have registered successfully.. Please login to continue")
    },
    error=>{
      alert("User Already Exists")
      console.log("Registration failed "+error)
    }
  )
}
 

  ngOnInit(): void {
  }

}
