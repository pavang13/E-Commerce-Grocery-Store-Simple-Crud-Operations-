import { Itemsdata } from './itemsdata';

describe('Itemsdata', () => {
  it('should create an instance', () => {
    expect(new Itemsdata()).toBeTruthy();
  });
});
