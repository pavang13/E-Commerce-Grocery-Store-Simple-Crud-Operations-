import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Itemsdata } from './itemsdata';

@Injectable({
  providedIn: 'root'
})
export class ItemserviceService {

  constructor(private httpClient:HttpClient) { }

  reqHeader=new HttpHeaders().set('Authorization','Bearer '+window.localStorage.getItem('tkn'))

  getitem:string="http://localhost:8070/groceries"

  display(){
    let reqHeader=new HttpHeaders().set('Authorization','Bearer '+window.localStorage.getItem('tkn'))
    return this.httpClient.get<any>(this.getitem+"/getallitems",{'headers':reqHeader})
  }

  additem:string="http://localhost:8070/groceries"
  onSub(data:Itemsdata){
    return this.httpClient.post<any>(this.additem+"/additem",data,{'headers':this.reqHeader})
  }

  updateitem:string="http://localhost:8070/groceries/update"
  onUpdate(data:Itemsdata){
    return this.httpClient.put<any>(this.updateitem+"/"+window.localStorage.getItem('c1'),data,{'headers':this.reqHeader});
  }

  delete:string="http://localhost:8070/groceries/delete"
  onDelete(){
    return this.httpClient.delete<any>(this.delete+"/"+window.localStorage.getItem('c2'),{'headers':this.reqHeader});
  }


}
