import { Userdata } from './userdata';

describe('Userdata', () => {
  it('should create an instance', () => {
    expect(new Userdata()).toBeTruthy();
  });
});
