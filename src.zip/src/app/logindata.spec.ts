import { Logindata } from './logindata';

describe('Logindata', () => {
  it('should create an instance', () => {
    expect(new Logindata()).toBeTruthy();
  });
});
