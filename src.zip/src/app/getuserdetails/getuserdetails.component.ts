import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getuserdetails',
  templateUrl: './getuserdetails.component.html',
  styleUrls: ['./getuserdetails.component.css']
})
export class GetuserdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
