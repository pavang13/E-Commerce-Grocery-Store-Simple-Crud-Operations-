import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Itemsdata } from '../itemsdata';
import { ItemserviceService } from '../itemservice.service';



@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent {

  constructor(private itemservice: ItemserviceService, private redirect: Router) { }

  itemdata: Itemsdata;

  additem = new FormGroup({
    itemCode: new FormControl('', [Validators.required]),
    itemName: new FormControl('', [Validators.required]),
    itemPrice: new FormControl('', [Validators.required]),
    quantity: new FormControl('', [Validators.required]),
    expiryDate: new FormControl('', [Validators.required])

  });

  onSubmit() {
    console.log(this.additem.value)
    this.itemdata = this.additem.value;
    //this.itemservice.onDelete(this.itemdata).subscribe(
    this.itemservice.onSub(this.itemdata).subscribe(
      result => {
        console.log("Item added " + result)
        alert("Item Added")
        this.redirect.navigateByUrl('/getitem');
      },
      error => {
        console.log("Item already exists " + error)
        alert("Items exists")
        this.redirect.navigateByUrl('/getitem');
      });

  }

  get itemCode() {
    return this.additem.get('itemCode')
  }
  get itemName() {
    return this.additem.get('itemName')
  }
  get itemPrice() {
    return this.additem.get('itemPrice')
  }
  get expiryDate() {
    return this.additem.get('expiryDate')
  }
  get quantity() {
    return this.additem.get('quantity')
  }





}
