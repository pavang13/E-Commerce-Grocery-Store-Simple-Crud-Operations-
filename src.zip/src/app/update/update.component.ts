import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Itemsdata } from '../itemsdata';
import { ItemserviceService } from '../itemservice.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(private itemservice: ItemserviceService, private redirect: Router) { }

  itemdata: Itemsdata;
  updateitem = new FormGroup({
    itemCode: new FormControl('', [Validators.required]),
    itemName: new FormControl('', [Validators.required]),
    itemPrice: new FormControl('', [Validators.required]),
    expiryDate: new FormControl('', [Validators.required]),
    quantity: new FormControl('', [Validators.required])
  })

  get itemCode() {
    return this.updateitem.get('itemCode')
  }
  get itemName() {
    return this.updateitem.get('itemName')
  }
  get itemPrice() {
    return this.updateitem.get('itemPrice')
  }
  get expiryDate() {
    return this.updateitem.get('expiryDate')
  }
  get quantity() {
    return this.updateitem.get('quantity')
  }

  ngOnInit(): void {
  }

  onUpdate() {
    console.log(this.updateitem.value)
    this.itemdata = this.updateitem.value;
    this.itemservice.onUpdate(this.itemdata!).subscribe(
      result => {
        console.log("Item Updated " + result)
        alert("Item updated")
        this.redirect.navigateByUrl('/getitem');
      },

    )
  }

}
