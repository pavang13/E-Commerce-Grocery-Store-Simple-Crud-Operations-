export class Itemsdata {
    constructor(
        public itemCode?: string,
        public itemName?: string,
        public itemPrice?: string,
        public quantity?: string,
        public expiryDate?: string

    ) { }
} 
