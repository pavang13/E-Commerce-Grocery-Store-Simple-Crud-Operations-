import { Signupdata } from './signupdata';

describe('Signupdata', () => {
  it('should create an instance', () => {
    expect(new Signupdata()).toBeTruthy();
  });
});
